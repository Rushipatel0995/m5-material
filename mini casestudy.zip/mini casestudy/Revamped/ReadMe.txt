Module 5 - Mini Project + PLP
			(40%) + (60%) 


1) The entire case study should be done using  Java
2) Change all the JSP pages to Java POJO classes
3) At the end take all the screen shots
4) Refer the evaluation split up

Deliverables:

1)Query Tracking Sheet (QTS)
2)MOM(Minutes of Meeting)

--------------Next Staurday-----------------
1)Test Cases
2) TestReports
3) Defect Tracking sheets
---------------------------------------

StartUML:

Open star UML,select default mode,View,Diagram Explorer,Select the diag type


